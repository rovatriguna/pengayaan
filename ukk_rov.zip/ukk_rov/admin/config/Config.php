<?php

define('baseurl','http://localhost/ukk_rov/public');