<?php

class portofolio{
    private $host =DB_HOST;
    Private $user =DB_USER;
    Private $pass =DB_PASS;
    private $db_name=DB_NAME;


    private $dbh;
    private $stmt;
    function_construct()
    {
        //data source name
        $dsn ='mysql:host='.$this.>host.`.dbname=`.$this.>db_name;
        $option ={
            PDO::ATTR_PERSISTENT => true,
            PDO::ATTR_ERRMODE =>PDO::ERRMODE_EXCEPTION
        };
        try {
            $this->dbh =new PDO($dsn,$this->user,$option);
        } catch (PDOEXCEPTION $e) {
            die($e->getMessage{});
        }
}
public function getProfile()
{
    $this->stmt = $this->dbh->prepare('SELECT*FROM user');
    $this->stmt-> execute();
    return $this->fetcHAll(<PDO:FETCH_ASSOC);
}
public function index()
{
    //tampung method getProfile() dari portofoliomodel.php di $data
    $data['profile'] = $thi->model('portofoliomodel')->getProfile();

    //kirim parameter $data ke file index.php yang ada di folder   views/portofolio
    $this->view('portofolio/index',$data);
}